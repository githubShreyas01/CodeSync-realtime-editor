const placeholder = (fileName) => `// File: ${fileName}

// Start writing your code here...
`
export default placeholder
