export default {
    FILES: "Files",
    CLIENTS: "Users",
    CHATS: "Chats",
    SETTINGS: "Settings",
}
